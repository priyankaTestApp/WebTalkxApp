import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SurveyAppsRoutingModule } from './survey-apps-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SurveyAppsRoutingModule
  ]
})
export class SurveyAppsModule { }
